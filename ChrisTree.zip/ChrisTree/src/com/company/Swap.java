package com.company;
import java.util.*;
public class Swap {
    public static void main(String[] args) {
        Scanner input=new Scanner (System.in);
        System.out.print("Please input a number to be swapped: ");
        int d=input.nextInt();
        int swapped=swapDigitPairs(d);
        System.out.println("The swapped result is: " + swapped);

        System.out.print("\nPlease input a string to be swapped: ");
        String si=input.next();
        String ssi=swapLetterPairs(si);
        System.out.println("The swapped result is: " + ssi);
    }

    public static int swapDigitPairs(int n) {
            int result = 0;
            int m = 1;

            while(n > 0) {
                int d1 = n % 10;
                n /= 10;

                if(n == 0) {
                    result += m * d1;
                    break;
                }

                int d2 = n % 10;
                result = result + m * 10 * d1 + m * d2;
                n /= 10;
                m *= 100;
            }
            return result;
        }

    public static String swapLetterPairs(String string){
        String newString = "";

        for (int i = 0; i < string.length() / 2; i++) {
            newString += string.charAt(2 * i + 1);
            newString += string.charAt(2 * i);
        }

        if (string.length() % 2 != 0) {
            newString += string.charAt(string.length() - 1);
        }

        return newString;
    }
}
